using System;

namespace welcome
{
    class Program
    {
        static void Main(string[] args)
        {
            short num1 = 3;
            short num2 = 5;
            short sum = (short)(num1 + num2); //type casting

            Console.WriteLine(sum);

        }
    }
}