﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace deneme_cs408project_server
{
    public partial class Server : Form
    {
        private TcpListener server;  //our server
        private List<TcpClient> clients = new List<TcpClient>();  // list of client who will join the game
        private Dictionary<string, int> playerScores = new Dictionary<string, int>();  // to keep playyerscros to put on leaderboard
        private const int MAX_PLAYERS = 4; // it is 4 player game
        private bool isListening = false; // to manage server's status
        private CancellationTokenSource countdownTokenSource;  // to cancel countdown of game wbecause a player's disconnection
        private List<Player> activePlayers = new List<Player>();    // it is declared to show active playing members to clients

        private Queue<TcpClient> waitingQueue = new Queue<TcpClient>(); // queue to keep the waiting players


        public Server()   //initializing leaderboard scores and server
        { 
            InitializeComponent();
            LoadInitialScores();
        }

        private void Form1_Load(object sender, EventArgs e) // empty
        {

        }

        private void LoadInitialScores() // to fill leaderboard wti the data comes from "leaderboard.txt" 
        {
            try
            {
                foreach (var line in File.ReadAllLines("leaderboard.txt"))
                {
                    var parts = line.Split(',');
                    if (parts.Length == 2)
                    {
                        playerScores[parts[0].Trim()] = int.Parse(parts[1]);
                    }
                }
            }
            catch (Exception ex)
            {
                AppendTextSafe(richTextBox1, "Error loading initial scores: " + ex.Message + "\n");
            }
            UpdateLeaderboard();
        }

        private void InitializeServer( string portNumberString) // getting predefined port number form server GUI (as we understand) and checking its validity, after that starting the server
        {

            if (!int.TryParse(portNumberString, out int port))
            {
                MessageBox.Show("Invalid port number.");
                return;
            }

            try
            {
                server = new TcpListener(System.Net.IPAddress.Any, port);
                server.Start();
                isListening = true;

                server.BeginAcceptTcpClient(new AsyncCallback(OnClientConnect), null);
                AppendTextSafe(richTextBox1, $"Server started. Listening for players on {System.Net.IPAddress.Any}:{port}...\n");
            }
            catch (Exception ex)
            {
                AppendTextSafe(richTextBox1, $"Error starting server: {ex.Message}\n");
            }
        }

        private void OnClientConnect(IAsyncResult ar) // Built to maage clients connection
        {
            if (!isListening)
            {
                return;
            }
            TcpClient client = server.EndAcceptTcpClient(ar);
            if (clients.Count >= MAX_PLAYERS) // if number of clients are maxed, thenput them in queue
            {
                waitingQueue.Enqueue(client);
                SendMessage(client, "The room is full, you have been added to the waiting queue.");
            }
            else // else onnecting the players to game room
            {
                clients.Add(client);
                AppendTextSafe(richTextBox1, "Player connected. Total players: " + clients.Count + "\n");
                Task.Run(() => HandleClient(client));
                
                CheckPlayersReady();
            }
            server.BeginAcceptTcpClient(new AsyncCallback(OnClientConnect), null);
        }

        private void BroadcastPlayerList() // Sending active players to clients through this function
        {
            string message = "Players:" + string.Join(",", activePlayers.Select(p => p.Name));
            foreach (var player in activePlayers)
            {
                SendMessage(player.Client, message);
            }
        }

        private void HandleClient(TcpClient client) // checking Player's names and connection whether it is allowed or not, and informing clients
        {
            var stream = client.GetStream();
            var buffer = new byte[1024];
            int bytesRead;

            try
            {
                while ((bytesRead = stream.Read(buffer, 0, buffer.Length)) != 0)
                {
                    // Convert bytes to string
                    var data = Encoding.UTF8.GetString(buffer, 0, bytesRead);
                    if (!playerScores.ContainsKey(data))
                    {
                        playerScores[data] = 0;  // Initialize score for new player
                        AppendTextSafe(richTextBox1, $"Player {data} connected.\n");
                        foreach (var cl in clients)
                        {
                            SendMessage(cl, $"Player {data} joined the room.\n");
                        }
                        UpdateLeaderboard();
                    }
                    else
                    {
                        AppendTextSafe(richTextBox1, $"Player {data} reconnected.\n");
                    }

                    if (!activePlayers.Any(p => p.Name.Equals(data, StringComparison.OrdinalIgnoreCase)))
                    {
                        var newPlayer = new Player(data, client);
                        activePlayers.Add(newPlayer);
                        BroadcastPlayerList(); // Update everyone with the new list of active players

                        // Continue to handle the client normally
                        // Task.Run(() => HandleClient(newPlayer));
                    }
                    else
                    {
                        // Handle the case where a player with the same name tries to connect again
                        SendMessage(client, "A player with this name is already connected.");
                    }

                    if (true)
                    {
                        
                    }
                    else
                    {
                        
                    }
                }
            }
            catch (Exception ex)
            {
                AppendTextSafe(richTextBox1, $"Error: {ex.Message}\n");
            }
            finally
            {
                OnClientDisconnect(client);

            }
        }

        private async void CheckPlayersReady() // checking if the room is maxed and if it is maxed, countdown starts, if a player leaes during the countdown, aborts
        {
            if (clients.Count == MAX_PLAYERS)
            {
                foreach (var client in clients)
                {
                    SendMessage(client, "Game will start in 5 seconds...");
                }

                // Cancel any existing countdown
                countdownTokenSource?.Cancel();
                countdownTokenSource = new CancellationTokenSource();

                try
                {
                    await StartCountdown(5, countdownTokenSource.Token);
                    foreach (var client in clients)
                    {
                        SendMessage(client, "Go!");
                    }
                }
                catch (OperationCanceledException)
                {
                    if (clients.Count < MAX_PLAYERS)
                    {
                        foreach (var client in clients)
                        {
                            SendMessage(client, "Countdown aborted. Waiting for more players.");
                        }
                    }
                    while (clients.Count < MAX_PLAYERS && waitingQueue.Count > 0)
                    {
                        var nextClient = waitingQueue.Dequeue();
                        clients.Add(nextClient);
                        SendMessage(nextClient, "You have been added to the game.");
                    }
                    
                    CheckPlayersReady();

                }
            }
        }

        private async Task StartCountdown(int seconds, CancellationToken token) // starting countdown like "5, 4, 3, 2, 1, GO" like in hte Project document
        {
            for (int i = seconds; i > 0; i--)
            {
                token.ThrowIfCancellationRequested();
                foreach (var client in clients)
                {
                    SendMessage(client, i.ToString());
                }
                await Task.Delay(1000, token); // Wait for 1 second
            }
        }

        private void OnClientDisconnect(TcpClient client) // when a player disconnects, this function manages the disconnection
                                                          // on the server and informng other clients, if there is a waiting player at queue, puts him/her in the game room
        {
            lock (clients) // through locks managing threads and concurrency
            {
                if (clients.Contains(client))
                {
                    clients.Remove(client);
                    Player playerDisc = activePlayers.FirstOrDefault(p => p.Client == client);
                    AppendTextSafe(richTextBox1, "Player disconnected. Total players: " + clients.Count + "\n");
                    foreach (var it in clients)
                    {
                        SendMessage(it, $"Player {playerDisc.Name} left the room.\n");
                    }
                }
                else if (waitingQueue.Contains(client))
                {
                    // Handle situation where a waiting client disconnects if necessary
                }
            }
            lock (activePlayers)
            {
                Player playerToRemove = activePlayers.FirstOrDefault(p => p.Client == client);
                activePlayers.Remove(playerToRemove);
                BroadcastPlayerList();
            }
            if (countdownTokenSource != null && clients.Count < MAX_PLAYERS)
            {
                countdownTokenSource.Cancel();
            }
        }

        private void SendMessage(TcpClient client, string message) // fuction works for communication to clients
        {
            byte[] data = Encoding.ASCII.GetBytes(message);
            client.GetStream().BeginWrite(data, 0, data.Length, null, null);
        }

        private void UpdateLeaderboard() // it is built for updating leaderboard according to game results or newcoming player
        {
            if (dataGridView1.InvokeRequired)
            {
                dataGridView1.BeginInvoke(new MethodInvoker(() => UpdateLeaderboard()));
            }
            else
            {
                DataTable dt = new DataTable();
                dt.Columns.Add("Player");
                dt.Columns.Add("Wins");
                foreach (var playerScore in playerScores.OrderByDescending(p => p.Value))
                {
                    dt.Rows.Add(playerScore.Key, playerScore.Value);
                }
                dataGridView1.DataSource = dt;
            }
        }

        private void AppendTextSafe(RichTextBox rtb, string text) // appending text messages onto server GUI to inform people wh manages server (who is us :))
        {
            if (rtb.InvokeRequired)
            {
                rtb.BeginInvoke(new MethodInvoker(() => AppendTextSafe(rtb, text)));
            }
            else
            {
                rtb.AppendText(text);
            }
        }

        protected override void OnFormClosing(FormClosingEventArgs e) // when the project is stopped, this is working.
        {
            base.OnFormClosing(e);
            if (server != null)
            {
                server.Stop();
            }
            foreach (var client in clients)
            {
                client.Close();
            }
        }

        private void listenButton_Click(object sender, EventArgs e) // taking the predefined port number from server guı
        {
            string portNumber = portTextbox.Text;

            InitializeServer( portNumber);
            listenButton.Enabled = false;
            closeButton.Enabled = true;
        }

        private void DisconnectServer() // stopping the server without closing the project
        {
            try
            {
                // Set the listening flag to false to stop accepting new connections
                isListening = false;

                // Stop accepting new client connections
                server.Stop();

                // Optionally, close all existing client connections
                foreach (var client in clients)
                {
                    client.Close();
                }
                clients.Clear(); // Clear the list of clients

                // Display a message indicating that the server has stopped
                AppendTextSafe(richTextBox1, "Server stopped.\n");
            }
            catch (Exception ex)
            {
                // Handle any exceptions that occur during server stopping
                AppendTextSafe(richTextBox1, $"Error stopping server: {ex.Message}\n");
            }
        }

        private void button1_Click(object sender, EventArgs e) // basicallydisconnecting server button 
        {
            DisconnectServer();
            listenButton.Enabled = true;
            closeButton.Enabled = false;
        }

        private void richTextBox1_TextChanged(object sender, EventArgs e) // empty
        {

        }
    }
    public class Player // to build "activeplayers" list, stroing name and the client
    {
        public string Name { get; set; }
        public TcpClient Client { get; set; }

        public Player(string name, TcpClient client)
        {
            Name = name;
            Client = client;
        }
    }
}
