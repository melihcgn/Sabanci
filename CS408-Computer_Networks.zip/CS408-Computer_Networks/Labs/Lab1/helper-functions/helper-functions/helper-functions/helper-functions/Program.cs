﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace helper_functions
{
    class Program
    {
        static void Main(string[] args)
        {

            string text = "test";

            Console.WriteLine("Text: " + text);
            
            // 1 - iterate through the characters in a text
            foreach(char ch in text)
            {
                Console.WriteLine(ch);
            }

            // 2 - get the ascii value of a char
            char mychar = 't';
            Console.WriteLine((int) mychar);

            // 3 - parse a string into an integer
            string number_str = "1234";
            int number = Int32.Parse(number_str);
            Console.WriteLine(number);

            // 4 - convert an integer into a string
            string num_str = number.ToString();
            Console.WriteLine(num_str);

            // 5 - Convert a string into a byte array
            Byte[] text_buffer = Encoding.Default.GetBytes(text);

            // 6 - Convert a byte array into a string
            string resulting_text = Encoding.Default.GetString(text_buffer);
            Console.WriteLine(resulting_text);
            
        }
    }
}
