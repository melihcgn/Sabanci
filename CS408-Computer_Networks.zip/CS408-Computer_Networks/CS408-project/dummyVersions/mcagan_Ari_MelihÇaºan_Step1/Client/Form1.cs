﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using Newtonsoft.Json;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace deneme_cs408project
{


    public partial class ClientMain : Form
    {
        private TcpClient client;  // declaration of client
        private NetworkStream stream; // declaration of stream to pass infos
        private Thread receiveThread; // using thread to manage communication with the server at background
        private List<Player> currentPlayers = new List<Player>();  // it is equal to activePlayers list in the server, to show client the current player in the game room 
        public ClientMain()  // initializing client
        {
            InitializeComponent();
            client = new TcpClient();

        }

        private void ClientMain_Load(object sender, EventArgs e) //empty
        {

        }

        private void button1_Click(object sender, EventArgs e) // "connect the game" button, checking ip address and port, then accordingly connecting the client to the server 
        {
            try // with thry and catch blocks, tracking the bugs or network problems
            {
                if (client == null)
                {
                    client = new TcpClient();
                }

                string serverIP = clientIPtextbox.Text;
                int serverPort;

                if (!int.TryParse(clientPort.Text, out serverPort))
                {
                    MessageBox.Show("Invalid port number.");
                    return;
                }

                if (!client.Connected)
                {
                    client.Connect(serverIP, serverPort);
                }

                if (client.Connected) // informing the client with the connection
                {
                    // Connection successful
                    stream = client.GetStream();
                    clientRTB.AppendText("Connected to server.\n");

                    string username = playerName.Text;
                    byte[] data = Encoding.ASCII.GetBytes(username);
                    stream.Write(data, 0, data.Length);
                    clientRTB.AppendText("Username sent: " + username + "\n");

                    clientConnectBtn.Enabled = false;
                    disconnectBtn.Enabled = true;

                    receiveThread = new Thread(new ThreadStart(ReceiveMessages));
                    receiveThread.IsBackground = true;
                    receiveThread.Start();
                }
                else
                {
                    MessageBox.Show("Failed to connect to the server.");
                }
            }
            catch (SocketException ex)
            {
                MessageBox.Show("SocketException: " + ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error connecting to server: " + ex.Message);
            }
        }


        private void label2_Click(object sender, EventArgs e) // empty
        {

        }

        private void clientPort_TextChanged(object sender, EventArgs e) // empty
        {

        }

        private void playerName_TextChanged(object sender, EventArgs e) //empty
        {

        }


        protected override void OnFormClosing(FormClosingEventArgs e) // fucntion that works when the clien project is terminated, closng th stream and the client itself, also abortinng the thread for clear consisten connections
        {
            base.OnFormClosing(e);
            if (client != null && client.Connected)
            {
                try
                {
                    stream.Close();
                    client.Close();

                    // Join the receiveThread with a timeout
                    if (receiveThread != null && receiveThread.IsAlive)
                    {
                        if (!receiveThread.Join(1000)) // Wait for 1 second
                        {
                            receiveThread.Abort(); // If the thread does not terminate, forcefully abort it
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error during closing: " + ex.Message);
                    
                }
            }
        }



        //receiving messages
        private void ReceiveMessages() // reading messages comes from the server and handling them, like message strating with "players:" are put in player listbox
        {
            try
            {
                byte[] buffer = new byte[1024];
                int bytes;
                while (client.Connected && stream != null && (bytes = stream.Read(buffer, 0, buffer.Length)) != 0)
                {
                    string message = Encoding.ASCII.GetString(buffer, 0, bytes);
                    if (message.StartsWith("Players:"))
                    {
                        string playersData = message.Substring(8);
                        string[] players = playersData.Split(',');
                        Invoke((MethodInvoker)delegate
                        {
                            playerListBox.Items.Clear();
                            foreach (var player in players)
                            {
                                playerListBox.Items.Add(player);
                            }
                        });
                    }
                    else
                    {
                        Invoke((MethodInvoker)delegate
                        {
                            clientRTB.AppendText("Server: " + message + "\n");
                        });
                    }
                }
            }

            catch (Exception ex)
            {
                if (this.IsHandleCreated) // Check if form is still open before updating UI
                {
                    Invoke((MethodInvoker)delegate
                    {
                        //clientRTB.AppendText("Disconnected from server: " + ex.Message + "\n");
                    });
                }
            }
        }

        private void button1_Click_1(object sender, EventArgs e) // Disconnect from the game button
        {
            if (client != null && client.Connected)
            {
                try
                {
                    // Close the stream and client
                    stream.Close(); // Use the class-level stream variable
                    client.Close();
                    playerListBox.Items.Clear();
                    // Clean up resources
                    stream = null;
                    client = null;

                    // Update UI
                    clientConnectBtn.Enabled = true;
                    disconnectBtn.Enabled = false;
                    clientRTB.AppendText("Disconnected from the server.\n");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error disconnecting: " + ex.Message);
                }
            }
            else // it is designed to solve theb ug when server is stopped while the client seems connected in clients GUI
            {
                MessageBox.Show("You are not connected to the server.");
                client = null;
                clientConnectBtn.Enabled = true;
                disconnectBtn.Enabled = false;
            }
        }


        // rock, paper, scissor buttons at further steps in the game 
        private void btnRock_Click(object sender, EventArgs e) // rock button at further steps
        {
            SendChoice("Rock");

        }

        private void button2_Click(object sender, EventArgs e) //paper button
        {
            SendChoice("Paper");

        }

        private void btnScissors_Click(object sender, EventArgs e) // scissor button
        {
            SendChoice("Scissors");

        }

        private void SendChoice(string choice) // sending the one of the choices "r, p,s" which is selected y client is sent to server at this function
        {
            if (client.Connected)
            {
                byte[] data = Encoding.ASCII.GetBytes(choice);
                stream.Write(data, 0, data.Length);
                clientRTB.AppendText("Choice sent: " + choice + "\n");
            }
            else
            {
                MessageBox.Show("You must be connected and joined before sending a choice.");
            }
        }


        // Method to update the player list in the ListBox
        private void UpdatePlayerListBox() // updating currentplayers according to certain operations like disconnection of a player in the game room
        {
            playerListBox.Items.Clear(); // Clear existing items

            foreach (Player player in currentPlayers)
            {
                // Display each player's name and wins in the ListBox
                string playerInfo = $"{player.Name} (Wins: {player.Wins})";
                playerListBox.Items.Add(playerInfo);
            }
            playerListBox.Refresh(); // Refresh the ListBox display

        }

        // Method to handle received player list from server
        private void HandleReceivedPlayerList(string playerListJson)
        {
            try
            {
                // Deserialize the JSON string to List<Player> using Newtonsoft.Json
                List<Player> receivedPlayers = JsonConvert.DeserializeObject<List<Player>>(playerListJson);

                // Update the current players list
                currentPlayers = receivedPlayers;

                // Update the ListBox with the updated player list
                UpdatePlayerListBox(); // Check if this method is called and executed
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error handling received player list: {ex.Message}");
            }
        }

        // to simulate receiving player list from server (used in the process of playerlistbox)
        private void SimulateReceivedPlayerList()
        {
            // Sample JSON string representing player list
            string sampleJson = "[{\"Name\":\"Player1\",\"Wins\":5},{\"Name\":\"Player2\",\"Wins\":3}]";

            // Handle the received player list
            HandleReceivedPlayerList(sampleJson);
        }

        private void ClientForm_Load(object sender, EventArgs e)
        {
            // Simulate receiving the player list when the form loads (for demonstration)
            SimulateReceivedPlayerList();
        }
    }

    public class Player // it is equilavent to the "player" class at the server, it will be extended at further
    {
        public string Name { get; set; }
        public int Wins { get; set; }
    }
}
