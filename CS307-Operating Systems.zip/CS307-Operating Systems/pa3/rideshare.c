#include <stdio.h>
#include <pthread.h>
#include <semaphore.h>
#include <stdlib.h>

sem_t barrier;
sem_t barrierLine;
pthread_mutex_t mutex;
pthread_cond_t cond;
int carID = 0; // to implement IDs of the car who fans goes
int numOfPlaces = 4; // to hold how many places left for monitorizin the accepted fans
// int numOfWaiting = 0; holding the number of fans who entered but not accepted, waiting; it is not necessary since I used condition variable instead
int num;
// created to store team names of the fans
typedef struct {
    char* teamName;
} TeamData;

// created to store number of the fans who are accepted to the current car
typedef struct {
    int teamAcount;
    int teamBcount;
} gameData;

gameData mainData = {0};




void* gameTime(void* arg) {
    TeamData* teamInfo = (TeamData*)arg;

    pthread_mutex_lock(&mutex);
    printf("Thread ID: %ld, Team: %s, I am looking for a car.\n", (long)pthread_self(), teamInfo->teamName);
    
    // the while loops at below are checking whether they are sutiable for the current car team or not, if they are not, they unlock the mutex and waiting the barrier to open
    while (
    (mainData.teamAcount == 2 && mainData.teamBcount == 1 && teamInfo->teamName == "A") ||
    (mainData.teamAcount == 1 && mainData.teamBcount == 2 && teamInfo->teamName == "B") ||
    (mainData.teamAcount == 3 && teamInfo->teamName == "B") ||
    (mainData.teamBcount == 3 && teamInfo->teamName == "A")
    ) {
        // these commanded lines was the first attempt to blck the unaccepted users using semaphores
        //numOfWaiting++;
        //pthread_mutex_unlock(&mutex);  
        //sem_wait(&barrierLine);
        //pthread_mutex_lock(&mutex);
        pthread_cond_wait(&cond, &mutex);
    }
    if (teamInfo->teamName == "A") // this Part accepting the fan and saving their team name
    {
        mainData.teamAcount += 1;
    }
    else
    {
        mainData.teamBcount += 1;
    }


    if (mainData.teamAcount >=2 && mainData.teamBcount >=2) // this part checking 4 people band is done or not
    {
        mainData.teamAcount -= 2;
        mainData.teamBcount -= 2;
        sem_post(&barrier);
    }
    else if (mainData.teamAcount == 4)
    {
        mainData.teamAcount -= 4;
        sem_post(&barrier);
    }
    else if (mainData.teamBcount == 4)
    {
        mainData.teamBcount -= 4;
        sem_post(&barrier);
    }
    else
    {
        pthread_mutex_unlock(&mutex); // if the fan is not the 4th member, unlocks the mutex here
    }
    
    //accepted fans are waiting to find car
    sem_wait(&barrier);
    numOfPlaces--; // if a fan goes to the car, one seat is taken.
    printf("Thread ID: %ld, Team: %s, I have found a spot in a car.\n", (long)pthread_self(), teamInfo->teamName);
    if (numOfPlaces == 0) // it is designed for 4th member of the car which is driver
    {
        printf("Thread ID: %ld, Team: %s, I am the captain and driving the car with ID %d.\n", (long)pthread_self(), teamInfo->teamName, carID);
        carID++;
        numOfPlaces = 4; // new car is came, so that there are 4 places in the car again for newcomers
        pthread_cond_broadcast(&cond);

        // these commanded lines at the below was the first attempt to release unaccepted users block using semaphores
        // for (size_t i = 0; i < numOfWaiting; i++)    
        // {
        //     sem_post(&barrierLine); // releasing barriers to access the fans who are not accepted because of the rule
        // }
        //numOfWaiting = 0; reseting the waiting fans because there are not waiting anymore
        pthread_mutex_unlock(&mutex); 
        
    }
    else
    {
        sem_post(&barrier);
    }
    
    
    
    
    


    return NULL;
}

int main(int argc, char *argv[]) {
    // initializing barriers using semaphores, "solution.py" is used to implement.
    sem_init(&barrier, 0, 0);
    sem_init(&barrierLine, 0, 0);
    pthread_mutex_init(&mutex, NULL);
    pthread_cond_init(&cond, NULL);
    if (argc != 3) {
        printf("Usage: %s <num_teamA_threads> <num_teamB_threads>\n", argv[0]);
        return -1;
    }
    // taking inputs from the shell
    int num_teamA_threads = atoi(argv[1]);
    int num_teamB_threads = atoi(argv[2]);
    int num_all_fans = num_teamA_threads + num_teamB_threads;
    pthread_t teamA[num_teamA_threads];
    pthread_t teamB[num_teamB_threads];

    // to pass the team names of the fans to gameTime function
    TeamData teamA_data = {.teamName = "A"};
    TeamData teamB_data = {.teamName = "B"};
    
    // check validity of argument
    if (num_teamA_threads % 2 == 0 && num_teamB_threads % 2 == 0 && num_all_fans% 4 == 0 )
    {
        // Create threads for Team A
        for (int i = 0; i < num_teamA_threads; ++i) {
            pthread_create(&teamA[i], NULL, gameTime, (void*)&teamA_data);
        }
        // Create threads for Team B
        for (int i = 0; i < num_teamB_threads; ++i) {
            pthread_create(&teamB[i], NULL, gameTime, (void*)&teamB_data);
        }

        // Wait for all threads to finish
        for (int i = 0; i < num_teamA_threads; ++i) {
            pthread_join(teamA[i], NULL);
        }
        for (int i = 0; i < num_teamB_threads; ++i) {
            pthread_join(teamB[i], NULL);
        }
    }
    else
    {
        printf("Validation error\n");
    }
    
    


    // destroys the smaphores, otherwise they will work until system close
    sem_destroy(&barrier);
    pthread_mutex_destroy(&mutex);
    pthread_cond_destroy(&cond);
    printf("The main terminates\n");

    return 0;
}
