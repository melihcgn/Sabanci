#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <fcntl.h>
#include <assert.h>
#include <sys/wait.h>

int main(int argc, char *argv[])
{
	printf("I'm SHELL process, with PID: %d - Main command is: man touch | grep -A 1 -e '-c' > output.txt\n", getpid());
	int fd[2];
	pipe(fd);       //to use between parent and first child

	int fd2[2];     //to use between parent and second child
	pipe(fd2);
	
	
	char myOut[10000];
	
	//man command
	char *myTouch[] = {"man", "touch", NULL};
	//grep option
	char *myGrep[] = {"grep", "-A 1", "-e", "-c", NULL};
	
	
	int rc = fork(); //fork to create first child process
	if (rc < 0) {
		fprintf(stderr, "fork failed\n");
		exit(1);
	}
	else if (rc == 0) { // if first child of parent 
		printf("I'm MAN process, with PID: %d - My command is: man touch\n", getpid());
		dup2(fd[1], STDOUT_FILENO);
		close(fd[0]);
        	close(fd[1]);
        	        	
		execvp(myTouch[0], myTouch);
	}
	else { //parent process
		
		int rc2 = fork();  //fork to create second child process
		wait(NULL); // waiting for first child process (man) 
		if (rc2 < 0) {
		    fprintf(stderr, "fork failed\n");
		    exit(1);
		}
		else if (rc2 == 0 ) { 
		    //second child process
		    printf("I'm GREP process, with PID: %d - My command is: grep -A 1 -e '-c' > output.txt\n", getpid());
		    close(fd[1]);
		    close(fd2[0]);
		   
		    dup2(fd[0], STDIN_FILENO);
		    close(fd[1]);
            	    close(fd[0]);
		    
		    dup2(fd2[1], STDOUT_FILENO);
			
		    execvp(myGrep[0], myGrep);
		}
		else{
		    //parent process
		    close(fd[1]);
                    close(fd[0]);
		    wait(NULL); //waiting for second child process (grep) 
		    printf("I'm SHELL process, with PID: %d - execution is completed, you can find the results in output.txt\n", getpid());
		    read(fd2[0], myOut, 10000);
		    FILE *file = fopen("output.txt","w");
		    fputs(myOut, file);
		    
		    //printf("%s\n", myOut);
		    
		}
	}
	return 0;
}
