//MELİH ÇAĞAN ARI - 28426

#include <iostream>
#include <pthread.h>

using namespace std;

struct heapNode //struct used in linked list implementation of the assignment
{
    int id;
    int size;
    int index;
    heapNode* next;

    heapNode(int idIN, int sizeIN, int indexIN, heapNode* nextIN)
        {
            id = idIN;
            size = sizeIN;
            index = indexIN;
            next = nextIN;
        }
};

class HeapManager
{
private:
    heapNode* head;  //  head pointer which points to free list
    pthread_mutex_t heapLock;  //  mutex lock belongs to the class member, built for concurrency
    void coalesce(heapNode* firstNode, heapNode* secondNode); //  a private member function for coalescing firstNode with secondNode, which is called in myFree()
public:
    HeapManager();
    ~HeapManager();
    int initHeap(int size);
    int myMalloc(int ID, int size);
    int myFree(int ID, int index);
    void print();

};

HeapManager::HeapManager() // default constructor 
    {
        head = NULL;
        heapLock =PTHREAD_MUTEX_INITIALIZER;
    }

HeapManager::~HeapManager() { // destructor
    // Free the allocated memory for each node in the linked list

    while (head != nullptr) {
        heapNode* temp = head;
        head = head->next;
        delete temp;
    }

    // Destroy the mutex
    pthread_mutex_destroy(&heapLock);
}


int HeapManager::initHeap(int size) { // built as told in the PA pdf
    head = new heapNode(-1, size, 0, NULL);
    cout << "Memory initialized" << endl;
    this->print();
    return 1;
}


int HeapManager::myMalloc(int allocateID, int allocateSize) {
    pthread_mutex_lock(&heapLock);
    int returnVal;  // I used this value to store the return value, otherwise i must use several unlocks which cause segmantation fault
    heapNode* workerNode = head, tempNode(-1,-1,-1, head);
    heapNode* prevNode = &tempNode;

    while (workerNode != nullptr) //  looking for a suitable chunk
    {
        if (workerNode->id == -1 && workerNode->size >= allocateSize) {
            break;
        }
        workerNode = workerNode->next;
        prevNode = prevNode->next;
    }

    if (workerNode == nullptr) {  //  if suitable chunk is not found
        cout << "Can not allocate, requested size " << allocateSize << " for thread " << allocateID << " is bigger than remaining size" << endl;
        print();
        returnVal = -1;
    }
    else {  //  otherwise, suitable chunk is found for a thread with given parameters
        heapNode* newAllocation = new heapNode(allocateID, allocateSize, workerNode->index, workerNode);   //  allocating new chunk with the given parameters
        
        if (prevNode->index == -1) { // the first time a chunk will be allocated, only head move since there is no previous node
            head = newAllocation;
        }
        else { // otherwise, new node becomes the next of the previous node
            prevNode->next = newAllocation; 
        }

        // preparing the index and size numbers of the workerNode so that new chunk will be implemented
        workerNode->index += allocateSize; 
        workerNode->size -= allocateSize;
        
        if (workerNode->size == 0) {   //  if second chunk's size is 0 after splitting (which means the chunk found has a size exact that required)
            newAllocation->next = workerNode->next;
            delete workerNode;
        }
        returnVal = newAllocation->index;

        cout << "Allocated for thread " << allocateID << endl;
        this->print();
        
        
    }

    pthread_mutex_unlock(&heapLock);
    return returnVal;
}

int HeapManager::myFree(int freeID, int freeIDX) { // it is designed for a request in order to free a chunk 
    pthread_mutex_lock(&heapLock);
    int returnVal;
    heapNode* workerNode = head, tempNode(-2,-1,-1, head); 
    heapNode* prevNode = &tempNode;

    while (workerNode != NULL) //  looking for the current chunk, if not workerNode becomes NULL
    {
        if (workerNode->id == freeID && workerNode->index == freeIDX) { //checking ID and idx to find the current chınk if exists
            break;
        }
        workerNode = workerNode->next;
        prevNode = prevNode->next;
    }
    
    if (workerNode == NULL) {  //  the situation that current chunk does not exist, ex. trying to free 2nd thread while there is no allocated memory for 2nd thread
        cout << "Can not free, there is no such chunk allocated by thread " << freeID <<  " with index " << freeIDX << endl;
        print();
        returnVal = -1;
    }
    else {  //  current chunk exists
        workerNode->id = -1;   //  freeing the chunk


        //  freeing cases on page 3, figure 2 in PA4 document

        if (prevNode->id != -1 && workerNode->next->id != -1) { // 1st case, do nothing in this case
            int x = 3; // dummy variable 
        }
        else if (prevNode->id == -1 && workerNode->next->id != -1) { // 2th case: coalesce previous chunk and the current chunk
            coalesce(prevNode, workerNode);
        }
        else if (prevNode->id != -1 && workerNode->next->id == -1) { // 3th case: coalesce current chunk with the next chunk
            coalesce(workerNode, workerNode->next);
        }
        else if (prevNode->id == -1 && workerNode->next->id == -1) { // 4th case: coalesce previous, current and next chunk
            coalesce(workerNode, workerNode->next);
            coalesce(prevNode, workerNode);
        }

        returnVal = 1;
        cout << "Freed for thread " << freeID << endl;
        print();
    }

    pthread_mutex_unlock(&heapLock);
    return returnVal;
}


void HeapManager::print() { // it is designed to print the resulted nodes after each operation
    heapNode* workerNode = head;
    while (workerNode != NULL)
    {
        cout << "[" << workerNode->id << "][" << workerNode->size << "][" << workerNode->index << "]";
        if (workerNode->next != NULL) {
            cout << "---";
        }
        workerNode = workerNode->next;
    }
    cout << endl;
}

// private function
void HeapManager::coalesce(heapNode* firstNode, heapNode* secondNode) { //  combining firstNode with secondNode
    firstNode->size += secondNode->size;
    firstNode->next = secondNode->next;

    delete secondNode;
}
