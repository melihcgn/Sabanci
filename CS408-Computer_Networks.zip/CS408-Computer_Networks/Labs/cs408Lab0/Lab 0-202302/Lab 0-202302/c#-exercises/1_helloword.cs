using System;

namespace welcome
{
    class Program
    {
        static void Main(string[] args)
        {
        	Console.Write("Hello World! \n");
            Console.WriteLine("Hello World!");
        }
    }
}
