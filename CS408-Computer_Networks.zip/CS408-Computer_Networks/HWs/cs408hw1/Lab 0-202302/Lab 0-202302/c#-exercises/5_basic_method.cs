using System;

namespace welcome
{
    class Program
    {
        static int Add(int x, int y) //formal arguments 
        {
            int sum = x + y;
            return sum;
        }

        static void Main(string[] args)
        {
            int a = 5, b = 7;
            int result = Add(a, b); //actual arguments
            Console.WriteLine(result);

        }
    }
}
