#include <iostream>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <fcntl.h>
#include <assert.h>
#include <fstream>
#include <vector> //To store thread IDs, used for waiting
#include <sys/wait.h>
#include <sstream>

using namespace std;
pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER;

void * listener(void * arg){
    long int endRead = (long int)(arg); //Reads the end of the pipe
    bool flag = true;
    FILE * pipeFile;
    
    while(flag){ //Continuously listens, attempting to acquire a lock until the pipe's contents are printed on the console
        pthread_mutex_lock(&lock);
        pipeFile = fdopen(endRead, "r"); //Opens the pipe for reading
        char buff[100]; //Retrieves the message
        
        if(pipeFile){ //If the file was successfully opened
            if((fgets(buff, sizeof(buff), pipeFile) != NULL)){ //Verifies whether the file contains any content
                printf("------------- %ld\n", pthread_self());
                printf("%s", buff); //print the results
                fsync(STDOUT_FILENO);
                while (fgets(buff, sizeof(buff), pipeFile) != NULL){ //read it until EOF
                    printf("%s", buff);
                    fsync(STDOUT_FILENO);
                }
                printf("-------------- %ld\n", pthread_self());
                fsync(STDOUT_FILENO);
                flag = false;
            } //Otherwise, continuously attempts to acquire the lock until content is available
        }
        pthread_mutex_unlock(&lock);
    }
    fclose(pipeFile); // close the pipeFile
    return NULL;
}

int main(int argc, const char * argv[]) {
    ifstream file;
    file.open("commands.txt"); //input stream
    
    ofstream parse;
    parse.open("parse.txt"); //Stream for recording parsed commands

    string line, inputWord;
    vector<int> pIDs; //Holds IDs of child processes
    vector<pthread_t> tIDs; //Keeps track of thread identifiers
    
    while(getline(file, line)){ //Iterating through the commands.txt
        istringstream ss(line); //Reading each line by its inputWords
        ss >> inputWord; //The current inputWord signifies the command to execute
        
        char redirect = '-';
        string filename, input, options;
        
        char * command[4] = { NULL, NULL, NULL, NULL}; //the command typically consists of four elements: the command itself, input, option, and a null terminator for execvp
        command[0] = strdup(inputWord.c_str()); //the commant to be executed
        int idx = 1;
        
        while(ss >> inputWord){
            if (inputWord == ">"){ //theres a redirection
                redirect = '>'; //set redirect
                ss >> inputWord;
                filename = inputWord; //set filename
            }
            else if (inputWord == "<"){
                redirect = '<';
                ss >> inputWord;
                filename = inputWord;
            }
            else if (inputWord != "&"){ //& is the last thing in the line so if the inputWord is not that NOR the redirect things, means its a part of the command array.
                if (inputWord.find("-") == 0){ //checks if its an option
                    options = inputWord;
                }
                else{
                    input = inputWord;
                }
                command[idx] = strdup(inputWord.c_str()); //adds it to the array
                idx++;
            }
        }
        //the command was parsed, the array is ready
        parse << "----------" << endl;
        parse << "Command: " << command[0] << endl;
        parse << "Input: " << input << endl;
        parse << "Option: " << options << endl;
        parse << "Redirection: " << redirect << endl;
        parse << "Background: " << (inputWord == "&" ? "y": "n") << endl;
        parse << "----------" << endl;
        parse.flush();
        
        if (inputWord == "wait"){ // Ensuring completion to guarantee all output is processed
            for (int i = 0; i < pIDs.size(); i++){
                waitpid(pIDs[i], NULL, NULL);
            }
            pIDs.clear(); //clearing the memory
            
            for(int i=0; i <  tIDs.size(); i ++){
                pthread_join(tIDs[i], NULL);
            }
            tIDs.clear();
        }
        else{ //The command is set for execution via execvp
            if(redirect == '>'){ //The exceptional scenario where the command output isn't displayed on the console
                int pid_redirect = fork();
        
                if (pid_redirect < 0){
                    cout << "fork failed!!"<< endl;
                }
                else if (pid_redirect == 0){
                    int out = open(filename.c_str(), O_CREAT|O_WRONLY|O_TRUNC, S_IRWXU); //open the output file
                    dup2(out, STDOUT_FILENO); //make STDOUT into the output file
                    close(out); //close the unused one
                    execvp(command[0], command);
                }
                else{
                    if (inputWord != "&"){ //not a background
                        waitpid(pid_redirect, NULL, NULL); //Pausing to allow completion before proceeding with further command reading
                    }
                    else{
                        pIDs.push_back(pid_redirect); //push it back to keep track
                    }
                }
            }
            else{ //the output will be on console.
                int fd[2];
                pipe(fd);
                pthread_t thread1;
            
                int pidSP = fork();
                
                if(pidSP < 0){
                    cout << "Failed to fork!" << endl;
                }
                else if (pidSP == 0){
                    if (redirect == '<'){
                        int inputFile = open(filename.c_str(), O_RDONLY); // Accessing the file in a mode allowing only reading operations
                        dup2(inputFile, STDIN_FILENO); // Redirecting the input source to correspond to the specified file
                        close(inputFile); //close, not used
                        
                    }
                    close(fd[0]); //Disregarding the unused read end, then closing it
                    dup2(fd[1], STDOUT_FILENO); //Establishing the output as the anonymous pipe file
                    close(fd[1]);
                    execvp(command[0], command); //run the command
                }
                else{
                    close(fd[1]); // Discontinuing the write end, subsequently closing it
                    pthread_create(&thread1, NULL, listener, (void*) fd[0]); //Transferring the read end to the dedicated listener thread
                    if (inputWord != "&"){ //not background
                        waitpid(pidSP, NULL, NULL); // "wait"ing execution until certain conditions are met before resuming
                        pthread_join(thread1, NULL); //join the thread
                    }
                    else{ //push them to keep track
                        pIDs.push_back(pidSP);
                        tIDs.push_back(thread1);
                    }
                }
            }
        }
    }
    parse.close(); //close the files, work is done.
    file.close();
    
    //Ensuring completion by waiting and joining each thread to guarantee comprehensive printing
    for (int i=0; i < pIDs.size(); i++){
        waitpid(pIDs[i], NULL, NULL);
    }
    pIDs.clear();
    
    for(int i=0; i <  tIDs.size(); i ++){
        pthread_join(tIDs[i], NULL);
    }
    tIDs.clear();
    return 0;
}