﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ThreadExampleLab
{
    class Program
    {

        static void Method()
        {
            try
            {
                for (int i=0; i<500; i++)
                {
                    if(i == 100)
                    {
                        Thread.Sleep(3000);
                        Thread.CurrentThread.Abort();
                    }

                    Console.WriteLine("In method: " + i);

                }
            }
            catch
            {
                Console.WriteLine("Inside catch inside method");
            }
            finally
            {
                Console.WriteLine("Inside finally inside method");
            }
        }

        static void Main(string[] args)
        {

            Thread thread1 = new Thread(Method);
            thread1.Start();
           

            for(int i=0; i<500; i++)
            {

                Console.WriteLine("In main " + i);

            }

            Console.Read();

        }
    }
}
